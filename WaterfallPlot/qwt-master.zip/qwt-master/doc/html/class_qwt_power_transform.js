var class_qwt_power_transform =
[
    [ "QwtPowerTransform", "class_qwt_power_transform.html#af29ae09162f70bdf81bc5a6fabcb84ba", null ],
    [ "~QwtPowerTransform", "class_qwt_power_transform.html#a33a82c2e0a67e7463646e7dbb64ccff1", null ],
    [ "copy", "class_qwt_power_transform.html#abdfb2ccebc50e2553a08a6da56c7a5ba", null ],
    [ "invTransform", "class_qwt_power_transform.html#a07b557015e7cddf0ec673be07827db69", null ],
    [ "transform", "class_qwt_power_transform.html#ac4993cde4c64b2435379c1c5f4e54522", null ]
];