var class_qwt_compass_wind_arrow =
[
    [ "Style", "class_qwt_compass_wind_arrow.html#a55f11e28c9d87c0fb7c306ccd174f2a8", [
      [ "Style1", "class_qwt_compass_wind_arrow.html#a55f11e28c9d87c0fb7c306ccd174f2a8a62b689f03b4e974660ce1241942b09fc", null ],
      [ "Style2", "class_qwt_compass_wind_arrow.html#a55f11e28c9d87c0fb7c306ccd174f2a8a44a462b3f0fa85bf3fa8dc421484e529", null ]
    ] ],
    [ "QwtCompassWindArrow", "class_qwt_compass_wind_arrow.html#a1b5931f43dd7e72fc5a3e2c9b509769d", null ],
    [ "drawNeedle", "class_qwt_compass_wind_arrow.html#a6610a137458b1286185fdd6470e69d37", null ]
];