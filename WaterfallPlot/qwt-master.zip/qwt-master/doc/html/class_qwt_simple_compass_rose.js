var class_qwt_simple_compass_rose =
[
    [ "QwtSimpleCompassRose", "class_qwt_simple_compass_rose.html#a66cc98efe5717eaf11fb0e713cd1aa21", null ],
    [ "~QwtSimpleCompassRose", "class_qwt_simple_compass_rose.html#a157304c9a535126d33a80df9a9dad292", null ],
    [ "draw", "class_qwt_simple_compass_rose.html#a81ac925ddcc4ba29de333237c1cf2b6d", null ],
    [ "numThornLevels", "class_qwt_simple_compass_rose.html#a6ea00a06b07d87798e2630b489fb619e", null ],
    [ "numThorns", "class_qwt_simple_compass_rose.html#a2c4df8d87a99b4e84e077773bf60956c", null ],
    [ "setNumThornLevels", "class_qwt_simple_compass_rose.html#a45cbc152c610d096ecd4231b0f9ba549", null ],
    [ "setNumThorns", "class_qwt_simple_compass_rose.html#a841918913652b50fc85ea7e713daa37a", null ],
    [ "setShrinkFactor", "class_qwt_simple_compass_rose.html#afaf84e19eb8eb2360306860b02d46cfc", null ],
    [ "setWidth", "class_qwt_simple_compass_rose.html#a1439bd174d26b2f06baedc5fab048ed8", null ],
    [ "shrinkFactor", "class_qwt_simple_compass_rose.html#a60278de80aa517aaa0ab7af22d262c30", null ],
    [ "width", "class_qwt_simple_compass_rose.html#a3dbac7f18d6b4de2c202ddc7761d20f2", null ]
];