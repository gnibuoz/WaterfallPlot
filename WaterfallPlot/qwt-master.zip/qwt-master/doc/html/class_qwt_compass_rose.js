var class_qwt_compass_rose =
[
    [ "QwtCompassRose", "class_qwt_compass_rose.html#a23bb2634090d12711102f0add67d1170", null ],
    [ "~QwtCompassRose", "class_qwt_compass_rose.html#a04142768b55a3bfe9c17ea6878088674", null ],
    [ "draw", "class_qwt_compass_rose.html#ad974a3035da51a9cfb36fa04eb1c40a6", null ],
    [ "palette", "class_qwt_compass_rose.html#a36888d96ff67ae500fdfdee9b68940ad", null ],
    [ "setPalette", "class_qwt_compass_rose.html#a25f08ab6d05f4ad17b2e13395c60e7ca", null ]
];