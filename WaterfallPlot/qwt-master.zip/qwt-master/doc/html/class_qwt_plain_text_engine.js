var class_qwt_plain_text_engine =
[
    [ "QwtPlainTextEngine", "class_qwt_plain_text_engine.html#a0ad29b2229a879afe49b546704eb7079", null ],
    [ "~QwtPlainTextEngine", "class_qwt_plain_text_engine.html#a0ada8796b2caaff7bb8d61e9fb1b5143", null ],
    [ "draw", "class_qwt_plain_text_engine.html#a3f7c5cde543fd1dbb2420d5a1c619767", null ],
    [ "heightForWidth", "class_qwt_plain_text_engine.html#a0945714b810f806ae1338d6e3718d63e", null ],
    [ "mightRender", "class_qwt_plain_text_engine.html#aa6c7018d2a70422213129173f771f708", null ],
    [ "textMargins", "class_qwt_plain_text_engine.html#a10ca5c93726c523cc0b167afa5a4bac0", null ],
    [ "textSize", "class_qwt_plain_text_engine.html#a2c84f6ff5615a9118e9e65340d5529f0", null ]
];