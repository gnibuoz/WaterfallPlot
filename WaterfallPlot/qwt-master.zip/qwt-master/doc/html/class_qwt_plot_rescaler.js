var class_qwt_plot_rescaler =
[
    [ "ExpandingDirection", "class_qwt_plot_rescaler.html#a1c314e9513cef076a79381111aa67585", [
      [ "ExpandUp", "class_qwt_plot_rescaler.html#a1c314e9513cef076a79381111aa67585a10adc202ca84a06179b905db6802668c", null ],
      [ "ExpandDown", "class_qwt_plot_rescaler.html#a1c314e9513cef076a79381111aa67585a856d9a1fe75ed6398a1b3c4b60f3fbfd", null ],
      [ "ExpandBoth", "class_qwt_plot_rescaler.html#a1c314e9513cef076a79381111aa67585a3dfb8208dfb62200761e4221763db033", null ]
    ] ],
    [ "RescalePolicy", "class_qwt_plot_rescaler.html#a6a614b832876a7641cb5410ba81d9d6a", [
      [ "Fixed", "class_qwt_plot_rescaler.html#a6a614b832876a7641cb5410ba81d9d6aab8f9ce10c092bee12de74b05a46b6e9c", null ],
      [ "Expanding", "class_qwt_plot_rescaler.html#a6a614b832876a7641cb5410ba81d9d6aac0b9db1ea3c5666792c2a9813ca5d7e1", null ],
      [ "Fitting", "class_qwt_plot_rescaler.html#a6a614b832876a7641cb5410ba81d9d6aa30a43b11d9df23f66110b65d1e249db1", null ]
    ] ],
    [ "QwtPlotRescaler", "class_qwt_plot_rescaler.html#aa1ce3d8e9175773aef7aba6c6ea51f27", null ],
    [ "~QwtPlotRescaler", "class_qwt_plot_rescaler.html#ae34a0dbae9074c211f36c765142d8ddd", null ],
    [ "aspectRatio", "class_qwt_plot_rescaler.html#a967c144b0f165e9501dac8b05df243bf", null ],
    [ "canvas", "class_qwt_plot_rescaler.html#ad4aa9bf81032b822b848774ee21142ce", null ],
    [ "canvas", "class_qwt_plot_rescaler.html#a49e3d4084037f6786c5bb6a8d2c78047", null ],
    [ "canvasResizeEvent", "class_qwt_plot_rescaler.html#a5490a4a1b576b1118c095cc54810e2aa", null ],
    [ "eventFilter", "class_qwt_plot_rescaler.html#a66bf6632ed98a2145d33ff46cea510fc", null ],
    [ "expandingDirection", "class_qwt_plot_rescaler.html#a2b9504b21a4a0e58b7fece16fe1da434", null ],
    [ "expandInterval", "class_qwt_plot_rescaler.html#a3dfd3bd03394c66ede8e37478d32784c", null ],
    [ "expandScale", "class_qwt_plot_rescaler.html#a483023eca66dced4e806f1cd33ee5a35", null ],
    [ "interval", "class_qwt_plot_rescaler.html#a776307286ffe7600016c277e161090d5", null ],
    [ "intervalHint", "class_qwt_plot_rescaler.html#a0e7afcdf8a843dc3fe44abe65b444065", null ],
    [ "isEnabled", "class_qwt_plot_rescaler.html#a85a9b40054acaab051f3679db1547b81", null ],
    [ "orientation", "class_qwt_plot_rescaler.html#a7173f9e9e1d8a3c619f58c3993285a8a", null ],
    [ "plot", "class_qwt_plot_rescaler.html#aca7a946dd53744e4640be383cd161a7c", null ],
    [ "plot", "class_qwt_plot_rescaler.html#ae54220a61cab777a6cb60103091a0aa3", null ],
    [ "referenceAxis", "class_qwt_plot_rescaler.html#a001fcaffb3c05dacaa1b82d0847db9c9", null ],
    [ "rescale", "class_qwt_plot_rescaler.html#af4b1840575eb6812c23acd9be199e5df", null ],
    [ "rescale", "class_qwt_plot_rescaler.html#a1a98f9c7a1102e486ce81a2833799155", null ],
    [ "rescalePolicy", "class_qwt_plot_rescaler.html#ac5a49fa34b071da28517efe6212d81ea", null ],
    [ "setAspectRatio", "class_qwt_plot_rescaler.html#a31f71937b4cff3e60f74db83beb6d2de", null ],
    [ "setAspectRatio", "class_qwt_plot_rescaler.html#a94273b7f54bb6d2a6a65589ff383f4c8", null ],
    [ "setEnabled", "class_qwt_plot_rescaler.html#a6f1c886d127ec4943552170dc63edf29", null ],
    [ "setExpandingDirection", "class_qwt_plot_rescaler.html#aa2ecffbc14d951ab9f1809c14bc4e21b", null ],
    [ "setExpandingDirection", "class_qwt_plot_rescaler.html#a1e245488207ca6996247236f5158fdfe", null ],
    [ "setIntervalHint", "class_qwt_plot_rescaler.html#a07036d67ae897ebe95be5495598e468c", null ],
    [ "setReferenceAxis", "class_qwt_plot_rescaler.html#ae6e974481a36e28d4be15ed6bc871561", null ],
    [ "setRescalePolicy", "class_qwt_plot_rescaler.html#ae6b7df41b5387d0aed532559546e40b6", null ],
    [ "syncScale", "class_qwt_plot_rescaler.html#a7bc7b93437246ce733c23c808e0f8c57", null ],
    [ "updateScales", "class_qwt_plot_rescaler.html#a7a5e0cb38c63c986f59981a02cd9d5bb", null ]
];