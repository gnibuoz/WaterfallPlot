var class_qwt_legend_data =
[
    [ "Mode", "class_qwt_legend_data.html#aaa33cc8e6aec17440df5d4c38d7545b7", [
      [ "ReadOnly", "class_qwt_legend_data.html#aaa33cc8e6aec17440df5d4c38d7545b7add4342fbe2d82828b9ef7031c1b41a0b", null ],
      [ "Clickable", "class_qwt_legend_data.html#aaa33cc8e6aec17440df5d4c38d7545b7a39077c66db9fe2faf4d85a6f9266583f", null ],
      [ "Checkable", "class_qwt_legend_data.html#aaa33cc8e6aec17440df5d4c38d7545b7a250e05444c9927d83d3815d9f5593917", null ]
    ] ],
    [ "Role", "class_qwt_legend_data.html#a55bd21943c804101d956250ca43f93f9", [
      [ "ModeRole", "class_qwt_legend_data.html#a55bd21943c804101d956250ca43f93f9a4b558c65e634d5d467e1cda869aa576b", null ],
      [ "TitleRole", "class_qwt_legend_data.html#a55bd21943c804101d956250ca43f93f9a4d8e06d686916e2377f90b4eb1099080", null ],
      [ "IconRole", "class_qwt_legend_data.html#a55bd21943c804101d956250ca43f93f9a705dc61ee2bdfb3575cd89b6fb7e797f", null ],
      [ "UserRole", "class_qwt_legend_data.html#a55bd21943c804101d956250ca43f93f9a068a16339054e86f69c8406f52eafac0", null ]
    ] ],
    [ "QwtLegendData", "class_qwt_legend_data.html#a519e4f01583d051e4b2458ab9dfcb196", null ],
    [ "~QwtLegendData", "class_qwt_legend_data.html#a56608cc97875e7b3dd9340decd5231cb", null ],
    [ "hasRole", "class_qwt_legend_data.html#abfa62dcccd380d9ba41cd24923c1155f", null ],
    [ "icon", "class_qwt_legend_data.html#aea7d1ab69cc1cab86a949b48b92a71b4", null ],
    [ "isValid", "class_qwt_legend_data.html#aa4965e8711b0b4cb899b673fe8525392", null ],
    [ "mode", "class_qwt_legend_data.html#a08a30173e015c7e743ae257f9ceb4736", null ],
    [ "setValue", "class_qwt_legend_data.html#a1be4b4cf3c1df733744633ea6c02346a", null ],
    [ "setValues", "class_qwt_legend_data.html#a68c3bc398c541f345a12fa9321ad52ed", null ],
    [ "title", "class_qwt_legend_data.html#af8a49f7a6cc6991815f3163b21d70d44", null ],
    [ "value", "class_qwt_legend_data.html#a6d7b579487291f78d9cc26b59b53e32f", null ],
    [ "values", "class_qwt_legend_data.html#ad7a22d8fd13cce97d49eef4f48b897f7", null ]
];