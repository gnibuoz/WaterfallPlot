var class_qwt_curve_fitter =
[
    [ "Mode", "class_qwt_curve_fitter.html#a4a9b88b0ab2842395a7662735c833301", [
      [ "Polygon", "class_qwt_curve_fitter.html#a4a9b88b0ab2842395a7662735c833301a87fb6ae7b505e76e42456c6caacdc3af", null ],
      [ "Path", "class_qwt_curve_fitter.html#a4a9b88b0ab2842395a7662735c833301a86090d569665ef9f1d47f61ada986996", null ]
    ] ],
    [ "~QwtCurveFitter", "class_qwt_curve_fitter.html#a62919f309f0441d94adea94573d0f778", null ],
    [ "QwtCurveFitter", "class_qwt_curve_fitter.html#acd45c40e13a1c43a959daeb595f144e1", null ],
    [ "fitCurve", "class_qwt_curve_fitter.html#afa9bf5b328aa553229e204533a60fec0", null ],
    [ "fitCurvePath", "class_qwt_curve_fitter.html#a49b54c6e81081e9c8a583d8b5ccbab9c", null ],
    [ "mode", "class_qwt_curve_fitter.html#a8b0619d37b34e28d3881c2eb48cb50db", null ]
];