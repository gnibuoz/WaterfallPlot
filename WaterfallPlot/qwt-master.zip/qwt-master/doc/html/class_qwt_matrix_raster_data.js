var class_qwt_matrix_raster_data =
[
    [ "ResampleMode", "class_qwt_matrix_raster_data.html#a3c8def5d9ae452bd82e6c4b71b480209", [
      [ "NearestNeighbour", "class_qwt_matrix_raster_data.html#a3c8def5d9ae452bd82e6c4b71b480209acaa0a9e3b8afd376472d6a587a3f9873", null ],
      [ "BilinearInterpolation", "class_qwt_matrix_raster_data.html#a3c8def5d9ae452bd82e6c4b71b480209a6f25a9f1f27cb94525ce39df487af13f", null ],
      [ "BicubicInterpolation", "class_qwt_matrix_raster_data.html#a3c8def5d9ae452bd82e6c4b71b480209a9fde75b1f87fcdb21a5ef54bb3797700", null ]
    ] ],
    [ "QwtMatrixRasterData", "class_qwt_matrix_raster_data.html#a3e80514459cc6aab03cfd839da53e45e", null ],
    [ "~QwtMatrixRasterData", "class_qwt_matrix_raster_data.html#a15284284966f25383fe67f2e278f4869", null ],
    [ "interval", "class_qwt_matrix_raster_data.html#a1d8668b0d9fe4c98514e272837c2b563", null ],
    [ "numColumns", "class_qwt_matrix_raster_data.html#ab6c21de8fd8945b634624774f3b3d85b", null ],
    [ "numRows", "class_qwt_matrix_raster_data.html#aca86a73cc956acce6edd9731482ccc11", null ],
    [ "pixelHint", "class_qwt_matrix_raster_data.html#a8c32a3222b2b4ad15036898532e95ffa", null ],
    [ "resampleMode", "class_qwt_matrix_raster_data.html#afe2b274f467ae6ddb60c5d8f027ab8c6", null ],
    [ "setInterval", "class_qwt_matrix_raster_data.html#a69db38d8f920edb9dc3f0953ca16db8f", null ],
    [ "setResampleMode", "class_qwt_matrix_raster_data.html#a038effe6e4be13725b7a8d35370595fd", null ],
    [ "setValue", "class_qwt_matrix_raster_data.html#a4601944bceabd921cdaa544180576274", null ],
    [ "setValueMatrix", "class_qwt_matrix_raster_data.html#a578ffc26f04a9099e2b31fc2d9360adb", null ],
    [ "value", "class_qwt_matrix_raster_data.html#a0629b3294f3bcfd9cc210b06eeeff6c4", null ],
    [ "valueMatrix", "class_qwt_matrix_raster_data.html#a95b3ade23f3bce8b84702ce64cb20e3e", null ]
];