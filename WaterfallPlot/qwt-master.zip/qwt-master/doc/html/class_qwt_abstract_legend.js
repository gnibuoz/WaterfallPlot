var class_qwt_abstract_legend =
[
    [ "QwtAbstractLegend", "class_qwt_abstract_legend.html#a77092d06decd579fcde5c90875c3830b", null ],
    [ "~QwtAbstractLegend", "class_qwt_abstract_legend.html#a6d86d9c50679dea9fefafc457fc70814", null ],
    [ "isEmpty", "class_qwt_abstract_legend.html#a9904720ba92daf03d0e5d8559cc5cdfe", null ],
    [ "renderLegend", "class_qwt_abstract_legend.html#a2fe1ac5ac1448e4d86b7437505214d9c", null ],
    [ "scrollExtent", "class_qwt_abstract_legend.html#a619f3705f6f9be8c1f38df68d83a37ff", null ],
    [ "updateLegend", "class_qwt_abstract_legend.html#aa9fc80c9e1dcbcfef51b96a3bff268ca", null ]
];