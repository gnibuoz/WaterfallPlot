var class_qwt_plot_text_label =
[
    [ "QwtPlotTextLabel", "class_qwt_plot_text_label.html#a19466cb637c30cfce5abfe024cbc3e3a", null ],
    [ "~QwtPlotTextLabel", "class_qwt_plot_text_label.html#a20e024910ca49b8fd7326cbfca77df22", null ],
    [ "draw", "class_qwt_plot_text_label.html#ac8346fafbc181ebabf11dfee5ea4cc2f", null ],
    [ "invalidateCache", "class_qwt_plot_text_label.html#ac498a144d548eddd4209da5979815c76", null ],
    [ "margin", "class_qwt_plot_text_label.html#a763aac3304919aa398f7204545288e5e", null ],
    [ "rtti", "class_qwt_plot_text_label.html#af02e767cdb6808cb2a2490445f049184", null ],
    [ "setMargin", "class_qwt_plot_text_label.html#a28bba339d2996ae2a8a426575820a816", null ],
    [ "setText", "class_qwt_plot_text_label.html#adce2e99ef7816ff544c5a5525bf05006", null ],
    [ "text", "class_qwt_plot_text_label.html#a13a313efab5c13440fdd3c012f21911b", null ],
    [ "textRect", "class_qwt_plot_text_label.html#adca7b1bbbda60fc01e4eccf85b643db4", null ]
];