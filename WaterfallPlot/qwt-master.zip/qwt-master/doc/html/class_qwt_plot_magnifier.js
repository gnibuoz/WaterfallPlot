var class_qwt_plot_magnifier =
[
    [ "QwtPlotMagnifier", "class_qwt_plot_magnifier.html#a6edabe11a02cae3ae8e8adaa9013d109", null ],
    [ "~QwtPlotMagnifier", "class_qwt_plot_magnifier.html#a38c0508241885ea49542cc0f11c740df", null ],
    [ "canvas", "class_qwt_plot_magnifier.html#a833e0c42a9ffdc92a60a1d1b0828b8ec", null ],
    [ "canvas", "class_qwt_plot_magnifier.html#a8120b8a7147ec0b5731b3ded205634e1", null ],
    [ "isAxisEnabled", "class_qwt_plot_magnifier.html#ac1882d7be736011c914ba255dbd69f7f", null ],
    [ "plot", "class_qwt_plot_magnifier.html#ae0197fb4f393e149585ff62f8e29cea6", null ],
    [ "plot", "class_qwt_plot_magnifier.html#a1ec990fe14c37b005f68a75122908b52", null ],
    [ "rescale", "class_qwt_plot_magnifier.html#a5e42d398b1bae15eb01872ded96dba67", null ],
    [ "setAxisEnabled", "class_qwt_plot_magnifier.html#a5cabb28963de683b2f9f980e2a2230f1", null ]
];