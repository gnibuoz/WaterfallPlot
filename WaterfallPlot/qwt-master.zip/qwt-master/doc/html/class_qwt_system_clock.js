var class_qwt_system_clock =
[
    [ "elapsed", "class_qwt_system_clock.html#a6d373715eb0fac098f2f02ce42a660c9", null ],
    [ "isNull", "class_qwt_system_clock.html#a7cde59f783269c5f3542ec93f450f5bd", null ],
    [ "restart", "class_qwt_system_clock.html#a6be327dd133c1d7ecccfb95050eef7b9", null ],
    [ "start", "class_qwt_system_clock.html#a3408bd55b49582f7847865aacc7beb37", null ]
];