var class_qwt_c_pointer_data =
[
    [ "QwtCPointerData", "class_qwt_c_pointer_data.html#af428def7cdbefbc17adc44b6f7a756f0", null ],
    [ "sample", "class_qwt_c_pointer_data.html#a5b726e4dd1cf5f308a5db63b6c7dc106", null ],
    [ "size", "class_qwt_c_pointer_data.html#a558723d97d5488e33f027964c03461fd", null ],
    [ "xData", "class_qwt_c_pointer_data.html#a0110dfe294c6a8ffe8bf1a3ece33bb12", null ],
    [ "yData", "class_qwt_c_pointer_data.html#a1df32b9ef9fd3a17ea7b6e2379989883", null ]
];