var class_qwt_polar_magnifier =
[
    [ "QwtPolarMagnifier", "class_qwt_polar_magnifier.html#ae18757a8ee2be73c4cf264720cb37d18", null ],
    [ "~QwtPolarMagnifier", "class_qwt_polar_magnifier.html#ae8e07b7b25186ef3db390f2792e960d5", null ],
    [ "canvas", "class_qwt_polar_magnifier.html#ab7542ea6d40639e29fd5e802220922eb", null ],
    [ "canvas", "class_qwt_polar_magnifier.html#a0a868ff6b9f697132109f42276bc90ea", null ],
    [ "getUnzoomKey", "class_qwt_polar_magnifier.html#a1182a9812b166a5a6125f34ac9bec6a2", null ],
    [ "plot", "class_qwt_polar_magnifier.html#aabb702a524ca685d410005003c6fdf52", null ],
    [ "plot", "class_qwt_polar_magnifier.html#a50552ea78da101e78330e0a3fe40ebe7", null ],
    [ "rescale", "class_qwt_polar_magnifier.html#aa93767ff2c6f6d5a31887a5cf8617677", null ],
    [ "setUnzoomKey", "class_qwt_polar_magnifier.html#a87548a332156609548d036bce63239cf", null ],
    [ "unzoom", "class_qwt_polar_magnifier.html#a7785d799a0fd09225baaefaa36de9671", null ],
    [ "widgetKeyPressEvent", "class_qwt_polar_magnifier.html#a0eaa92ae6e8a94df5063b0e76f7317e3", null ]
];