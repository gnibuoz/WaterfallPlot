var class_qwt_dial_needle =
[
    [ "QwtDialNeedle", "class_qwt_dial_needle.html#aef3af79632ce784bc4d7332f6e269a1f", null ],
    [ "~QwtDialNeedle", "class_qwt_dial_needle.html#ac23b2af4af50042967c8cea87b474247", null ],
    [ "draw", "class_qwt_dial_needle.html#a7a078ac5316c918e6a7e97316d48383d", null ],
    [ "drawKnob", "class_qwt_dial_needle.html#a769a895b3fefd851b44021ca118f2422", null ],
    [ "drawNeedle", "class_qwt_dial_needle.html#a1e4fee366fec1838edc18890d9957f2b", null ],
    [ "palette", "class_qwt_dial_needle.html#ad4c32d58f2b8e77fd66e0dfc66b7c37a", null ],
    [ "setPalette", "class_qwt_dial_needle.html#ae850883a64501136bca64d6ea2d084b9", null ]
];